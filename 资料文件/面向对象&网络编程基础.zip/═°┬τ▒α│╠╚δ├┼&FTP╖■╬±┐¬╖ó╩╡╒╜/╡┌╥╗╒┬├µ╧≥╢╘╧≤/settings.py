# name='alex'
# age=18
# sex='female'



egon@5565487