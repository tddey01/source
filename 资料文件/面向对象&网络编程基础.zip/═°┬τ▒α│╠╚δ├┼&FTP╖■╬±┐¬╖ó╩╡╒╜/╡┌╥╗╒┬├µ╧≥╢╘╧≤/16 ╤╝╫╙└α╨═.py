# class Disk:
#     def read(self):
#         print('disk read')
#
#     def write(self):
#         print('disk write')
#
#
# class Text:
#     def read(self):
#         print('text read')
#
#     def write(self):
#         print('text write')
#
#
#
# # f=open(...)
# # f.read()
# # f.write()
#
# disk=Disk()
# text=Text()
#
# disk.read()
# disk.write()
#
# text.read()
# text.write()


#序列类型：列表list，元祖tuple，字符串str

l=list([1,2,3])
t=tuple(('a','b'))
s=str('hello')




# print(l.__len__())
# print(t.__len__())
# print(s.__len__())


# def len(obj):
#     return obj.__len__()


print(len(l))
print(len(t))
print(len(s))


















